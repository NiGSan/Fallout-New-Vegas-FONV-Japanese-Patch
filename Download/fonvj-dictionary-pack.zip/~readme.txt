�� Fo:NV ���{��|���Ə� (��+) �����p�b�N
    Fo:NV ���{��|���Ə� (��+) http://fonvj.ngnl.org/ 
    �o�͓���: 2015-11-06 14:02:02 JST

���̃t�@�C���́A�uFo:NV ���{��|���Ə� (��+)�v�ɓ��e���ꂽ���ׂĂ̖|����o�͂��ăA�[�J�C�u�ɂ������̂ł��B
���悻 1 ���Ԗ��Ɏ�����������Ă��܂��B

�o�͓��e: �����Ɩ󕶂̃Z�b�g
�o�͌`��: FOJP Type-2
�I�v�V����:
    �E�L��: FOJP2 �p�Ɍ����� ASCII �����ďo��

FOJP ���̂̎g�����͂����ł͐������܂���B�e�����ׂĂ��������B

fojp.xml �ւ̋L�q�̗���ȉ��ɋL�ڂ��Ă����܂��̂ŁA�Q�l�ɂ��Ă��������B

----------
<file jp="NVJP/fonvj_base_actor_value_ja.txt" en="NVJP/fonvj_base_actor_value_en.txt" type="2" />
<file jp="NVJP/fonvj_base_ammo_ja.txt" en="NVJP/fonvj_base_ammo_en.txt" type="2" />
<file jp="NVJP/fonvj_base_body_part_ja.txt" en="NVJP/fonvj_base_body_part_en.txt" type="2" />
<file jp="NVJP/fonvj_base_description_ja.txt" en="NVJP/fonvj_base_description_en.txt" type="2" />
<file jp="NVJP/fonvj_base_dialogue_ja.txt" en="NVJP/fonvj_base_dialogue_en.txt" type="2" />
<file jp="NVJP/fonvj_base_game_setting_ja.txt" en="NVJP/fonvj_base_game_setting_en.txt" type="2" />
<file jp="NVJP/fonvj_base_message_ja.txt" en="NVJP/fonvj_base_message_en.txt" type="2" />
<file jp="NVJP/fonvj_base_name_ja.txt" en="NVJP/fonvj_base_name_en.txt" type="2" />
<file jp="NVJP/fonvj_base_note_ja.txt" en="NVJP/fonvj_base_note_en.txt" type="2" />
<file jp="NVJP/fonvj_base_quest_objective_ja.txt" en="NVJP/fonvj_base_quest_objective_en.txt" type="2" />
<file jp="NVJP/fonvj_base_terminal_ja.txt" en="NVJP/fonvj_base_terminal_en.txt" type="2" />
<file jp="NVJP/fonvj_base_topic_ja.txt" en="NVJP/fonvj_base_topic_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc01_ammo_ja.txt" en="NVJP/fonvj_dlc01_ammo_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc01_body_part_ja.txt" en="NVJP/fonvj_dlc01_body_part_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc01_description_ja.txt" en="NVJP/fonvj_dlc01_description_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc01_dialogue_ja.txt" en="NVJP/fonvj_dlc01_dialogue_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc01_message_ja.txt" en="NVJP/fonvj_dlc01_message_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc01_name_ja.txt" en="NVJP/fonvj_dlc01_name_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc01_note_ja.txt" en="NVJP/fonvj_dlc01_note_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc01_quest_objective_ja.txt" en="NVJP/fonvj_dlc01_quest_objective_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc01_terminal_ja.txt" en="NVJP/fonvj_dlc01_terminal_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc01_topic_ja.txt" en="NVJP/fonvj_dlc01_topic_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc02_ammo_ja.txt" en="NVJP/fonvj_dlc02_ammo_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc02_body_part_ja.txt" en="NVJP/fonvj_dlc02_body_part_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc02_description_ja.txt" en="NVJP/fonvj_dlc02_description_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc02_dialogue_ja.txt" en="NVJP/fonvj_dlc02_dialogue_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc02_message_ja.txt" en="NVJP/fonvj_dlc02_message_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc02_name_ja.txt" en="NVJP/fonvj_dlc02_name_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc02_note_ja.txt" en="NVJP/fonvj_dlc02_note_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc02_quest_objective_ja.txt" en="NVJP/fonvj_dlc02_quest_objective_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc02_terminal_ja.txt" en="NVJP/fonvj_dlc02_terminal_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc02_topic_ja.txt" en="NVJP/fonvj_dlc02_topic_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc03_ammo_ja.txt" en="NVJP/fonvj_dlc03_ammo_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc03_body_part_ja.txt" en="NVJP/fonvj_dlc03_body_part_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc03_description_ja.txt" en="NVJP/fonvj_dlc03_description_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc03_dialogue_ja.txt" en="NVJP/fonvj_dlc03_dialogue_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc03_message_ja.txt" en="NVJP/fonvj_dlc03_message_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc03_name_ja.txt" en="NVJP/fonvj_dlc03_name_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc03_note_ja.txt" en="NVJP/fonvj_dlc03_note_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc03_quest_objective_ja.txt" en="NVJP/fonvj_dlc03_quest_objective_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc03_terminal_ja.txt" en="NVJP/fonvj_dlc03_terminal_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc03_topic_ja.txt" en="NVJP/fonvj_dlc03_topic_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc04_ammo_ja.txt" en="NVJP/fonvj_dlc04_ammo_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc04_description_ja.txt" en="NVJP/fonvj_dlc04_description_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc04_dialogue_ja.txt" en="NVJP/fonvj_dlc04_dialogue_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc04_message_ja.txt" en="NVJP/fonvj_dlc04_message_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc04_name_ja.txt" en="NVJP/fonvj_dlc04_name_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc04_note_ja.txt" en="NVJP/fonvj_dlc04_note_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc04_quest_objective_ja.txt" en="NVJP/fonvj_dlc04_quest_objective_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc04_terminal_ja.txt" en="NVJP/fonvj_dlc04_terminal_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc04_topic_ja.txt" en="NVJP/fonvj_dlc04_topic_en.txt" type="2" />
<file jp="NVJP/fonvj_base_activation_text_override_ja.txt" en="NVJP/fonvj_base_activation_text_override_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc01_activation_text_override_ja.txt" en="NVJP/fonvj_dlc01_activation_text_override_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc02_activation_text_override_ja.txt" en="NVJP/fonvj_dlc02_activation_text_override_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc03_activation_text_override_ja.txt" en="NVJP/fonvj_dlc03_activation_text_override_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc04_activation_text_override_ja.txt" en="NVJP/fonvj_dlc04_activation_text_override_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc05_message_ja.txt" en="NVJP/fonvj_dlc05_message_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc05_name_ja.txt" en="NVJP/fonvj_dlc05_name_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc06_ammo_ja.txt" en="NVJP/fonvj_dlc06_ammo_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc06_description_ja.txt" en="NVJP/fonvj_dlc06_description_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc06_message_ja.txt" en="NVJP/fonvj_dlc06_message_en.txt" type="2" />
<file jp="NVJP/fonvj_dlc06_name_ja.txt" en="NVJP/fonvj_dlc06_name_en.txt" type="2" />
<file jp="NVJP/fonvj_mod_awop_activation_text_override_ja.txt" en="NVJP/fonvj_mod_awop_activation_text_override_en.txt" type="2" />
<file jp="NVJP/fonvj_mod_awop_description_ja.txt" en="NVJP/fonvj_mod_awop_description_en.txt" type="2" />
<file jp="NVJP/fonvj_mod_awop_dialogue_ja.txt" en="NVJP/fonvj_mod_awop_dialogue_en.txt" type="2" />
<file jp="NVJP/fonvj_mod_awop_message_ja.txt" en="NVJP/fonvj_mod_awop_message_en.txt" type="2" />
<file jp="NVJP/fonvj_mod_awop_name_ja.txt" en="NVJP/fonvj_mod_awop_name_en.txt" type="2" />
<file jp="NVJP/fonvj_mod_awop_note_ja.txt" en="NVJP/fonvj_mod_awop_note_en.txt" type="2" />
<file jp="NVJP/fonvj_mod_awop_quest_objective_ja.txt" en="NVJP/fonvj_mod_awop_quest_objective_en.txt" type="2" />
<file jp="NVJP/fonvj_mod_awop_terminal_ja.txt" en="NVJP/fonvj_mod_awop_terminal_en.txt" type="2" />
<file jp="NVJP/fonvj_mod_awop_topic_ja.txt" en="NVJP/fonvj_mod_awop_topic_en.txt" type="2" />
<file jp="NVJP/fonvj_mod_brzl_description_ja.txt" en="NVJP/fonvj_mod_brzl_description_en.txt" type="2" />
<file jp="NVJP/fonvj_mod_brzl_dialogue_ja.txt" en="NVJP/fonvj_mod_brzl_dialogue_en.txt" type="2" />
<file jp="NVJP/fonvj_mod_brzl_message_ja.txt" en="NVJP/fonvj_mod_brzl_message_en.txt" type="2" />
<file jp="NVJP/fonvj_mod_brzl_name_ja.txt" en="NVJP/fonvj_mod_brzl_name_en.txt" type="2" />
<file jp="NVJP/fonvj_mod_brzl_note_ja.txt" en="NVJP/fonvj_mod_brzl_note_en.txt" type="2" />
<file jp="NVJP/fonvj_mod_brzl_quest_objective_ja.txt" en="NVJP/fonvj_mod_brzl_quest_objective_en.txt" type="2" />
<file jp="NVJP/fonvj_mod_brzl_terminal_ja.txt" en="NVJP/fonvj_mod_brzl_terminal_en.txt" type="2" />
<file jp="NVJP/fonvj_mod_brzl_topic_ja.txt" en="NVJP/fonvj_mod_brzl_topic_en.txt" type="2" />

----------